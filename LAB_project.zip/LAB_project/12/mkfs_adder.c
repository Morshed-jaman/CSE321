//Adder 
#define _FILE_OFFSET_BITS 64
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <inttypes.h>
#include <errno.h>
#include <time.h>

#ifndef BS
#define BS 4096u
#endif

#ifndef INODE_SIZE
#define INODE_SIZE 128u
#endif

#ifndef DIRECT_MAX
#define DIRECT_MAX 12
#endif

#ifndef ROOT_INO
#define ROOT_INO 1u
#endif

#ifndef GROUP_ID
#define GROUP_ID 12u  // <-- My group ID
#endif

#pragma pack(push,1)
typedef struct {
    //Create Superblock
    uint32_t magic, version, block_size;
    uint64_t total_blocks, inode_count;
    uint64_t inode_bitmap_start, inode_bitmap_blocks;
    uint64_t data_bitmap_start, data_bitmap_blocks;
    uint64_t inode_table_start, inode_table_blocks;
    uint64_t data_region_start,  data_region_blocks;
    uint64_t root_inode, mtime_epoch;
    uint32_t flags;
    uint32_t checksum; // --->crc32 over superblock[0..4091]
} superblock_t;

#pragma pack(pop)
_Static_assert(sizeof(superblock_t)==116, "superblock size mismatch");

#pragma pack(push,1)
typedef struct {
    //Create My Inode 
    uint16_t mode; uint16_t links; 
    uint32_t uid, gid; uint64_t size_bytes;
    uint64_t atime, mtime, ctime; uint32_t direct[DIRECT_MAX];
    uint32_t reserved_0, reserved_1, reserved_2;
    uint32_t proj_id, uid16_gid16;
    uint64_t xattr_ptr; 
    uint64_t inode_crc; //------>Low 4 bytes store crc32 of bytes [0..119]; high 4 bytes 0
} inode_t;
#pragma pack(pop)
_Static_assert(sizeof(inode_t)==INODE_SIZE, "inode size mismatch");

//-----> DIRECTORY ENTRY STRUCTURE
#pragma pack(push,1)
typedef struct { 
    uint32_t inode_no; uint8_t type; char name[58]; 
    uint8_t checksum; 
} dirent64_t;

#pragma pack(pop)
_Static_assert(sizeof(dirent64_t)==64, "dirent size mismatch");

// ================= CRC32 Helpers (Got from skeleton File) ================= //
//Make compact
static uint32_t CRC32_TAB2[256];
static void crc32_init2(void){ for(uint32_t i=0;i<256;i++){ uint32_t c=i; for(int j=0;j<8;j++) c=(c&1)?(0xEDB88320u^(c>>1)):(c>>1); CRC32_TAB2[i]=c; }}

static uint32_t crc32_2(const void* d, size_t n){ const uint8_t* p=(const uint8_t*)d; uint32_t c=0xFFFFFFFFu; for(size_t i=0;i<n;i++) c=CRC32_TAB2[(c^p[i])&0xFF]^(c>>8); return c^0xFFFFFFFFu; }

static uint32_t superblock_crc_finalize2(superblock_t *sb){ sb->checksum=0; uint32_t s=crc32_2((void*)sb, BS-4); sb->checksum=s; return s; }

static void inode_crc_finalize2(inode_t* iNODE){ uint8_t tmp[INODE_SIZE]; memcpy(tmp,iNODE,INODE_SIZE); memset(&tmp[120],0,8); uint32_t c=crc32_2(tmp,120); iNODE->inode_crc=(uint64_t)c; }

// CALL THIS Function "AFTER ALL OTHER SUPERBLOCK ELEMENTS HAVE BEEN FINALIZED"
static void dirent_checksum_finalize2(dirent64_t* de){ const uint8_t* p=(const uint8_t*)de; uint8_t x=0; for(int i=0;i<63;i++) x^=p[i]; de->checksum=x; }

// ============================= Finish ==================================== 

/* Its a helper Function to show the program’s usage instructions*/
static void usecase(const char* prog){
    fprintf(stderr, "Usage: %s --input <in.img> --output <out.img> --file <file_path>\n",  prog);
}
/*check if a bit is = Set*/
static int test_bit(const uint8_t* bm, uint64_t idx){ return (bm[idx>>3] >> (idx & 7)) & 1u; }
/*Set a bit*/
static void set_bit(uint8_t* bm, uint64_t idx){ bm[idx>>3] |= (uint8_t)(1u << (idx & 7)); }

/*Extract filename from a path.*/
static const char* base_name(const char* file_path){
    const char* s = strrchr(file_path, '/'); if (!s) s = strrchr(file_path, '\\');
    return s ? (s+1) : file_path;
}

//Validates the required arguments
int main(int argC, char** argV){
    const char *in_img=NULL, *out_img=NULL, *in_file=NULL;
    for (int i=1;i<argC;i++){
        if (!strcmp(argV[i],"--input")  &&  i+1<argC) in_img = argV[++i];
        else if (!strcmp(argV[i],"--output")  &&  i+1<argC) out_img = argV[++i];
        else if (!strcmp(argV[i],"--file")  &&  i+1<argC) in_file = argV[++i];
        else { 
            usecase(argV[0]); 
            return 1; 
        }
    }

    if (!in_img || !out_img || !in_file){ 
        usecase(argV[0]); 
        return 1; 
    }

    // ------> Read from  input image
    /*This portion safely loads the entire disk image into a heap buffer so that the program can manipulate it*/
    FILE* fd = fopen(in_img, "rb"); if(!fd){ perror("open input image"); return 1; }
    if (fseek(fd, 0, SEEK_END)!=0){
         perror("fseek"); fclose(fd); 
         return 1; 
        }
    long long sz = ftell(fd); if (sz<0){ perror("ftell"); fclose(fd); return 1; }
    rewind(fd);

    uint8_t* img = (uint8_t*)malloc((size_t)sz); if(!img){ perror("malloc"); fclose(fd); return 1; }
    if (fread(img,1,(size_t)sz,fd)!=(size_t)sz){ 
        perror("fread"); free(img); fclose(fd); 
        return 1; 
    }

    fclose(fd);

    crc32_init2();
    //Check for image isn’t trivially small
    if ((size_t)sz < BS){ 
        fprintf(stderr, "Input image: smaller than one block\n"); free(img); return 1; 
    }

    superblock_t* sb = (superblock_t*)(img + 0*BS);
    if (sb->magic != 0x4D565346u || sb->block_size != BS){
        fprintf(stderr, "Invalid, MiniVSFS Superblock\n"); free(img); return 1;
    }
    
    uint8_t* ibm = img + (size_t)sb->inode_bitmap_start * BS; //points inode bitmap
    uint8_t* dbm = img + (size_t)sb->data_bitmap_start * BS; //points data bitmp
    uint8_t* itab = img + (size_t)sb->inode_table_start * BS; //points inode table

    // ---------->Load file to add
    FILE* file_f = fopen(in_file, "rb"); if(!file_f){ perror("open file"); free(img); return 1; }
    if (fseek(file_f, 0, SEEK_END)!=0){ 
        perror("fseek file"); fclose(file_f); 
        free(img); return 1; 
    }
    //Manage to read the file content 
    long long f_size = ftell(file_f); if (f_size<0){ perror("ftell file"); fclose(file_f); free(img); return 1; }
    rewind(file_f);

    /*Ensure file can stored only the available Direct block pointers*/
    uint64_t blocks_need = (uint64_t)((f_size + (long long)BS - 1) / (long long)BS);
    if (blocks_need > DIRECT_MAX){
        fprintf(stderr, "error: file too large for MiniVSFS (>%d blocks)\n", DIRECT_MAX);
        fclose(file_f); 
        free(img); 
        return 1;
    }

    // ---->Find free inode (first-fit)
    int64_t free_inode_idx = -1;
    for (uint64_t i=0;i<sb->inode_count;i++){
        if (!test_bit(ibm, i)) { free_inode_idx =  (int64_t)i; break; }
    }

    if (free_inode_idx < 0){ 
        fprintf(stderr, "No Free Inode Available\n"); 
        fclose(file_f); free(img); 
        return 1; 
    }

    // ------>Collect free data blocks (first-fit)
    uint32_t data_blocks[DIRECT_MAX]; memset(data_blocks, 0, sizeof(data_blocks));
    uint64_t found=0;
    for (uint64_t idx=0; idx<sb->data_region_blocks && found<blocks_need; idx++){
        if (!test_bit(dbm, idx)) { data_blocks[found++] = (uint32_t)(sb->data_region_start + idx); }
    }
    if (found < blocks_need){
        fprintf(stderr, "Not enough free Data Blocks (need %" PRIu64 ")\n", blocks_need);
        fclose(file_f); 
        free(img); return 1;
    }

    // ----> Copy file data
    uint8_t* file_buff = (uint8_t*)malloc((size_t)f_size);//Allocates a buffer
    //If fails
    if(!file_buff){ 
        perror("malloc file_buff"); 
        fclose(file_f); free(img); return 1; 
    }
    //Check read doesn’t match the expected size or not?

    if (fread(file_buff,1,(size_t)f_size,file_f)!=(size_t)f_size){ 
        perror("fread file"); 
        free(file_buff); fclose(file_f); free(img); return 1; 
    }
    fclose(file_f);

    /*In This part -->writes file data into the image blocks and marked them as allocated.*/
    for (uint64_t i=0; i<blocks_need; i++){
        uint32_t block_no = data_blocks[i];
        size_t off = (size_t)block_no * BS;
        size_t n = (i==blocks_need-1)? (size_t)(f_size - (long long)i*BS) : BS;
        memcpy(img + off, file_buff + i*BS, n);

        if (n<BS) memset(img + off + n, 0, BS - n);
        set_bit(dbm, (block_no - sb->data_region_start));
    }
    free(file_buff);

    // ---> Create file inode
    inode_t* iNODE = (inode_t*)(itab + (size_t)free_inode_idx * INODE_SIZE);
    memset(iNODE, 0, sizeof(*iNODE));
    iNODE->mode = 0100000; // ---->regular file
    iNODE->links = 1;  iNODE->uid = 0;  iNODE->gid = 0;  iNODE->size_bytes = (uint64_t)f_size;
    iNODE->atime = iNODE->mtime = iNODE->ctime = (uint64_t)time(NULL);

    for (int j=0;j<DIRECT_MAX;j++) iNODE->direct[j] = (j<(int)blocks_need) ? data_blocks[j] : 0;

    /* here---> Set Our group id BEFORE computing the inode_CRC */
    iNODE->proj_id = GROUP_ID;

    inode_crc_finalize2(iNODE);
    set_bit(ibm, (uint64_t)free_inode_idx);

    // --->Update Our root directory
    inode_t* root = (inode_t*)(itab + 0*INODE_SIZE);

    // ----> Find a free dirent slot in existing direct blocks
    int slot_found = 0; uint32_t dirblk_use = 0; size_t dirent_offset = 0;
    for (int di=0; di<DIRECT_MAX && !slot_found; di++){
        uint32_t blck = root->direct[di]; if (!blck) continue;
        uint8_t* b = img + (size_t)blck * BS;
        for (int j=0;j<(int)(BS/sizeof(dirent64_t)); j++){
            dirent64_t* d = (dirent64_t*)(b + j*sizeof(dirent64_t));
            if (d->inode_no == 0){ slot_found=1; dirblk_use = blck; dirent_offset = j*sizeof(dirent64_t); break; }
        }
    }

    if (!slot_found){
        // --->Need a new directory block
        int di_free=-1; for (int di=0; di<DIRECT_MAX; di++){ if (root->direct[di]==0){ di_free=di; break; } }
        if (di_free<0){ fprintf(stderr, "Root directory has no Free direct slots\n"); free(img); return 1; }
        // --->find free data block for directory
        uint32_t new_Blk=0; for (uint64_t i=0;i<sb->data_region_blocks;i++){ if(!test_bit(dbm,i)){ new_Blk=(uint32_t)(sb->data_region_start+i); set_bit(dbm,i); break; } }
        if (!new_Blk){ fprintf(stderr, "No free block for expanding Directory\n"); free(img); return 1; }

        memset(img + (size_t)new_Blk*BS, 0, BS);
        root->direct[di_free] = new_Blk; dirblk_use = new_Blk; dirent_offset = 0; slot_found = 1;
    }


    // This part builds and writes the directory entry that links the new file into the filesystem.
    dirent64_t nde = (dirent64_t){0};
    nde.inode_no = (uint32_t)(free_inode_idx + 1); // --->1-indexed
    nde.type = 1; memset(nde.name, 0, sizeof(nde.name));

    const char* base_Name = base_name(in_file); strncpy(nde.name, base_Name, sizeof(nde.name));
    dirent_checksum_finalize2(&nde);
    memcpy(img + (size_t)dirblk_use*BS + dirent_offset, &nde, sizeof(nde));

    //---> Adjust root inode size & links; lastly refresh checksum
    root->size_bytes +=  sizeof(dirent64_t);
    root->links +=  1; // ----->Spec: new file refers to root via ".."
    root->mtime =  root->ctime = (uint64_t)time(NULL);
    inode_crc_finalize2(root);

    // -----> Update Superblock mtime & checksum
    sb->mtime_epoch = (uint64_t)time(NULL);
    superblock_crc_finalize2(sb);

    // -----> Write output image
    FILE* fl_out = fopen(out_img, "wb"); if(!fl_out){ perror("open output"); free(img); return 1; }
    if (fwrite(img,1,(size_t)sz,fl_out)!=(size_t)sz){ perror("fwrite output"); fclose(fl_out); free(img); return 1; }

    fclose(fl_out); 
    free(img);
    //----> provide a summary confirming the file was added to the filesystem image
    fprintf(stderr, "Added '%s' as inode #%d using %" PRIu64 " block(s). Output: %s\n",
            base_Name, 
            (int)(free_inode_idx+1), blocks_need, out_img);
    return 0;
}
