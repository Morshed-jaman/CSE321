// Build: gcc -O2 -std=c17 -Wall -Wextra mkfs_minivsfs.c -o mkfs_builder
#define _FILE_OFFSET_BITS 64
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <inttypes.h>
#include <errno.h>
#include <time.h>

#define BS 4096u               // block size
#define INODE_SIZE 128u
#define ROOT_INO 1u
#define DIRECT_MAX 12

#ifndef GROUP_ID
#define GROUP_ID 12u           // My group ID which is 12
#endif

//global seed
uint64_t g_random_seed = 0; // This is replaced by seed value from the CLI.

#pragma pack(push,1)
typedef struct {
    uint32_t magic;                 // --->0x4D565346 (Shows:"MVSF")
    uint32_t version;               // --->1
    uint32_t block_size;            // --->4096
    uint64_t total_blocks;          // --->Cal:size_kib*1024/4096
    uint64_t inode_count;           // from --->inodes
    uint64_t inode_bitmap_start;    // --->1
    uint64_t inode_bitmap_blocks;   // --->1
    uint64_t data_bitmap_start;     // --->2
    uint64_t data_bitmap_blocks;    // --->1
    uint64_t inode_table_start;     // --->3
    uint64_t inode_table_blocks;    // --->ceil(inodes*128/4096)
    uint64_t data_region_start;     // --->inode_table_start + inode_table_blocks
    uint64_t data_region_blocks;    // --->total_blocks - data_region_start
    uint64_t root_inode;            // --->1
    uint64_t mtime_epoch;           // --->building time
    uint32_t flags;                 // 0
    // ------->THIS FIELD  STAY AT THE END Of THIS CODE
    uint32_t checksum;              // crc32(superblock[0..4091])
} superblock_t;

#pragma pack(pop)
_Static_assert(sizeof(superblock_t)==116, "superblock must fit in one block");

#pragma pack(push,1)
typedef struct {
    uint16_t mode;          // --->0100000=file,0040000=dir(OCTAL)
    uint16_t links;         // --->Count Link
    uint32_t uid;           // --->0
    uint32_t gid;           // --->0
    uint64_t size_bytes;    // --->file size Or directory logical size
    uint64_t atime;         // --->Build time
    uint64_t mtime;         // --->Build time
    uint64_t ctime;         // --->Build time
    uint32_t direct[DIRECT_MAX]; // --->Absolute Block Numbers
    uint32_t reserved_0;    // --->0
    uint32_t reserved_1;    // --->0
    uint32_t reserved_2;    // --->0
    uint32_t proj_id;       // --->group id (set to our GROUP_ID)
    uint32_t uid16_gid16;   // --->0
    uint64_t xattr_ptr;     // --->0
    // THIS FIELD STAY AT THE END 
    uint64_t inode_crc;     // low32 ----> crc32 of Bytes [0..119]
} inode_t;
#pragma pack(pop)
_Static_assert(sizeof(inode_t)==INODE_SIZE, "inode size mismatch");

#pragma pack(push,1)
typedef struct {
    uint32_t inode_no;      // --->0 if it free
    uint8_t  type;          // --->1=file,2=dir
    char     name[58];      // --->zero-padded
    uint8_t  checksum;      // --->XOR of bytes 0..62
} dirent64_t;
#pragma pack(pop)
_Static_assert(sizeof(dirent64_t)==64, "dirent size mismatch");

/* ================= CRC32 helpers (from skeleton) ================= */
static uint32_t CRC32_TAB[256];
static void crc32_init(void){
    for (uint32_t i=0;i<256;i++){
        uint32_t c=i; 
        for(int j=0;j<8;j++) c = (c&1)?(0xEDB88320u^(c>>1)):(c>>1);
        CRC32_TAB[i]=c;
    }
}

static uint32_t crc32(const void* data, size_t n){
    const uint8_t* p=(const uint8_t*)data; uint32_t c=0xFFFFFFFFu;
    for(size_t i=0;i<n;i++) c = CRC32_TAB[(c^p[i])&0xFF] ^ (c>>8);
    return c ^ 0xFFFFFFFFu;
}
//----------------------CRC32-----------------------------------
static uint32_t superblock_crc_finalize(superblock_t *sb) {
    sb->checksum = 0; 
    uint32_t s = crc32((void*)sb, BS-4); sb->checksum = s; return s;
}

static void inode_crc_finalize(inode_t* ino){
    uint8_t tmp[INODE_SIZE]; memcpy(tmp, ino, INODE_SIZE); 
    memset(&tmp[120], 0, 8);//Zero crc area before Computing
    uint32_t c = crc32(tmp, 120); ino->inode_crc = (uint64_t)c;
}

static void dirent_checksum_finalize(dirent64_t* de){
    const uint8_t* p=(const uint8_t*)de; uint8_t x=0; for(int i=0;i<63;i++) x^=p[i]; de->checksum=x;
}

// ============================Main===================================== 

static void usecase(const char* prog){
    fprintf(stderr,
        "Usage: %s --image <out.image> --size-kib <180..4096> --inodes <128..512> [--seed <n>]\n",
        prog);
}
static void set_bit(uint8_t* bm, uint64_t idx){ bm[idx>>3] |= (uint8_t)(1u << (idx & 7)); }
//----------->Parse Command-line arguments
int main(int argC, char** argV){
    const char* output_img= NULL; long size_kib= -1, n_inodes= -1;
    for (int i=1; i<argC;i++){

        if (!strcmp(argV[i],"--image")  &&  i+1<argC) { output_img=argV[++i]; }
        else if (!strcmp(argV[i],"--size-kib")  &&  i+1<argC) { size_kib=strtol(argV[++i],NULL,10); }
        else if (!strcmp(argV[i],"--inodes")  &&  i+1<argC) { n_inodes=strtol(argV[++i],NULL,10); }
        else if (!strcmp(argV[i],"--seed")  &&  i+1<argC) { g_random_seed = strtoull(argV[++i], NULL, 10); }
        else { usecase(argV[0]); 
            return 1; }
    }

    if (!output_img || size_kib < 180 || size_kib> 4096 || (size_kib % 4)!= 0 || n_inodes < 128 || n_inodes > 512) {
        usecase(argV[0]); return 1;
    }

    crc32_init();

    //------> If need C's RNG elsewhere then this makes it reproducible
    if (g_random_seed != 0) {
         srand((unsigned)g_random_seed); 
        }

    uint64_t total_blocks = (uint64_t)size_kib * 1024u / BS;

    uint64_t inode_table_blocks = ((uint64_t)n_inodes * INODE_SIZE + (BS-1)) / BS;
    if (inode_table_blocks==0) {
         fprintf(stderr, "Invalid inode_table_blocks\n"); 
         return 1; 
        }
    //------------>This fills with metadata of the filesystem superblock 
    superblock_t sb = (superblock_t){0};
    sb.magic = 0x4D565346u; sb.version = 1; sb.block_size = BS;
    sb.total_blocks = total_blocks; 
    sb.inode_count = (uint64_t)n_inodes;
    sb.inode_bitmap_start = 1; 
    sb.inode_bitmap_blocks = 1;
    sb.data_bitmap_start = 2; 
    sb.data_bitmap_blocks = 1;
    sb.inode_table_start = 3; sb.inode_table_blocks = inode_table_blocks;
    sb.data_region_start = sb.inode_table_start + sb.inode_table_blocks;

    if (sb.data_region_start >= sb.total_blocks){
        fprintf(stderr, "Image size too small: insufficient for data region\n"); 
        return 1;
    }

    sb.data_region_blocks = sb.total_blocks - sb.data_region_start;
    sb.root_inode = ROOT_INO; 
    sb.mtime_epoch = (uint64_t)time(NULL); 
    sb.flags = 0;
    superblock_crc_finalize(&sb);

    size_t img_Bytes = (size_t)sb.total_blocks * BS;
    uint8_t* image = (uint8_t*)calloc(1, img_Bytes);

    if (!image){ 
        perror("calloc"); 
        return 1; 
    }

    memcpy(image  +  0*BS,  &sb,  sizeof(sb));

    // ----> Inode Bitmap : It will mark inode #1 which is used
    uint8_t* ibm = image + (size_t)sb.inode_bitmap_start * BS;
    set_bit(ibm, 0);

    //-----> Data Bitmap  : For root directory, allocate first data block 
    uint8_t* dbm = image + (size_t)sb.data_bitmap_start * BS;

    set_bit(dbm, 0);

    //-----> Table of Inode
    uint8_t* itab = image  +  (size_t)sb.inode_table_start * BS;

    inode_t* root = (inode_t*)  (itab + 0*INODE_SIZE); //...... Inode #1 --> Index )0

    // Create Root inode
    memset(root, 0, sizeof(*root));

    root->mode  = 040000;   //---->For directory
    root->links =  2;        // ----> For Current and Parent dir "." and ".."
    root->uid =  0; 
    root->gid =  0;
    root->size_bytes =  2 * sizeof(dirent64_t);
    root->atime =  root->mtime = root->ctime = (uint64_t)time(NULL);
    root->direct[0] =  (uint32_t) (sb.data_region_start  +  0);

    for (int idx = 1;idx < DIRECT_MAX;idx++) root->direct[idx]=0;
    // Here Set our group_id before computing CRC 
    root->proj_id = GROUP_ID;
    inode_crc_finalize(root);

    // -------> It Initializes (create and writes) ==>> "." & ".."
    uint8_t* root_Block = image + (size_t)root->direct[0] * BS;
    dirent64_t de = (dirent64_t){0};
    de.inode_no = ROOT_INO; 
    de.type = 2; memset(de.name, 0, sizeof(de.name));
    strncpy(de.name, ".", sizeof(de.name)); //--->Current 
    dirent_checksum_finalize(&de);
    memcpy(root_Block + 0*sizeof(dirent64_t), &de, sizeof(de));

    memset(&de, 0, sizeof(de));
    de.inode_no = ROOT_INO; de.type = 2; 
    memset(de.name, 0, sizeof(de.name));
    strncpy(de.name, "..", sizeof(de.name)); dirent_checksum_finalize(&de);//--->Parent
    memcpy(root_Block + 1*sizeof(dirent64_t), &de, sizeof(de));

    // -------------> Emit image(save image and finsh)

    FILE* fd = fopen(output_img, "wb");
    if (!fd){ 
        perror("fopen image"); free(image); 
        return 1; 
    }
    
    size_t bytes_w = fwrite(image, 1, img_Bytes, fd);
    if (bytes_w != img_Bytes){ 
        perror("fwrite"); fclose(fd); free(image); 
        return 1; // report error,clean up and exit
    } 

    //------>It close file and release the buffer
    fclose(fd); 
    free(image);

    //-------->Show final status message(Summary Print)
    fprintf(stderr, "Created MiniVSFS image '%s' (%ld KiB, %" PRIu64 " blocks, %ld inodes)%s%s\n",
            output_img, size_kib, 
            sb.total_blocks, n_inodes,
            g_random_seed ? " with seed=" : "",
            g_random_seed ? (char[32]){0} : "");
    //---> seed info
    if (g_random_seed){
        fprintf(stderr, "Seed used: %" PRIu64 "\n", g_random_seed);
    }
    return 0;
}
