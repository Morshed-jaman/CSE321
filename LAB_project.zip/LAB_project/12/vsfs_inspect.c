// Build: gcc -O2 -std=c11 -Wall -Wextra vsfs_inspect.c -o vsfs_inspect
#define _FILE_OFFSET_BITS 64
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>

#define BS 4096u
#define INODE_SIZE 128u
#define DIRECT_MAX 12
#define ROOT_INO 1u

#pragma pack(push,1)
typedef struct {
    uint32_t magic, version, block_size;
    uint64_t total_blocks, inode_count;
    uint64_t inode_bitmap_start, inode_bitmap_blocks;
    uint64_t data_bitmap_start,  data_bitmap_blocks;
    uint64_t inode_table_start,  inode_table_blocks;
    uint64_t data_region_start,  data_region_blocks;
    uint64_t root_inode, mtime_epoch;
    uint32_t flags;
    uint32_t checksum; // crc32 over [0..4091]
} superblock_t;
#pragma pack(pop)

#pragma pack(push,1)
typedef struct {
    uint16_t mode; uint16_t links; uint32_t uid, gid; uint64_t size_bytes;
    uint64_t atime, mtime, ctime; uint32_t direct[DIRECT_MAX];
    uint32_t reserved_0, reserved_1, reserved_2; uint32_t proj_id, uid16_gid16;
    uint64_t xattr_ptr; uint64_t inode_crc;
} inode_t;
#pragma pack(pop)

#pragma pack(push,1)
typedef struct { uint32_t inode_no; uint8_t type; char name[58]; uint8_t checksum; } dirent64_t;
#pragma pack(pop)

static int test_bit(const uint8_t* bm, uint64_t idx){ return (bm[idx>>3] >> (idx & 7)) & 1u; }

typedef struct {
    uint32_t ino;
    uint8_t  type;   // 1=file, 2=dir
    char     name[59];
} entry_t;

static void print_super(const superblock_t* sb){
    printf("== Superblock ==\n");
    printf("magic: 0x%08X  version: %u  block_size: %u\n", sb->magic, sb->version, sb->block_size);
    printf("total_blocks: %" PRIu64 "  inode_count: %" PRIu64 "\n", sb->total_blocks, sb->inode_count);
    printf("inode_bitmap: start=%" PRIu64 " blocks=%" PRIu64 "\n", sb->inode_bitmap_start, sb->inode_bitmap_blocks);
    printf("data_bitmap : start=%" PRIu64 " blocks=%" PRIu64 "\n", sb->data_bitmap_start,  sb->data_bitmap_blocks);
    printf("inode_table : start=%" PRIu64 " blocks=%" PRIu64 "  (bytes=%" PRIu64 ")\n",
           sb->inode_table_start, sb->inode_table_blocks,
           sb->inode_table_blocks * (uint64_t)BS);
    printf("data_region : start=%" PRIu64 " blocks=%" PRIu64 " (first byte offset=0x%08" PRIX64 ")\n",
           sb->data_region_start, sb->data_region_blocks,
           sb->data_region_start * (uint64_t)BS);
    printf("root_inode: %" PRIu64 "  mtime_epoch: %" PRIu64 "  checksum: 0x%08X\n\n",
           sb->root_inode, sb->mtime_epoch, sb->checksum);
}

int main(int argc, char** argv){
    if (argc != 2){
        fprintf(stderr, "Usage: %s <image.img>\n", argv[0]);
        return 1;
    }

    // load whole image
    FILE* f = fopen(argv[1], "rb");
    if (!f){ perror("fopen"); return 1; }
    if (fseek(f, 0, SEEK_END)!=0){ perror("fseek"); fclose(f); return 1; }
    long long sz = ftell(f);
    if (sz < 0){ perror("ftell"); fclose(f); return 1; }
    rewind(f);
    uint8_t* img = (uint8_t*)malloc((size_t)sz);
    if (!img){ perror("malloc"); fclose(f); return 1; }
    if (fread(img,1,(size_t)sz,f)!=(size_t)sz){ perror("fread"); free(img); fclose(f); return 1; }
    fclose(f);

    if ((size_t)sz < BS){ fprintf(stderr, "image too small\n"); free(img); return 1; }

    // map regions
    const superblock_t* sb = (const superblock_t*)(img + 0*BS);
    if (sb->block_size != BS || sb->magic != 0x4D565346u){
        fprintf(stderr, "invalid superblock\n"); free(img); return 1;
    }
    print_super(sb);

    const uint8_t* ibm = img + (size_t)sb->inode_bitmap_start * BS;
    const uint8_t* itab = img + (size_t)sb->inode_table_start * BS;
    const uint8_t* dbm = img + (size_t)sb->data_bitmap_start * BS;
        printf("== Data bitmap (first 16 bytes) ==\n");
        for (int i=0; i<16; i++) {
            printf("%02X ", dbm[i]);
        }
        printf("\n\n");

    // list allocated inodes
    printf("== Allocated inodes (from bitmap) ==\n");
    int first = 1;
    for (uint64_t i=0;i<sb->inode_count;i++){
        if (test_bit(ibm, i)){
            printf("%s%" PRIu64, first?"":", ", i+1);
            first = 0;
        }
    }
    if (first) printf("(none)");
    printf("\n\n");

    // read root inode
    const inode_t* root = (const inode_t*)(itab + (ROOT_INO-1)*INODE_SIZE);
    printf("== Root inode (#1) ==\n");
    printf("mode: 0x%04X  links: %u  size: %" PRIu64 "  proj_id: %u\n",
           root->mode, root->links, root->size_bytes, root->proj_id);
    printf("direct blocks:");
    for (int i=0;i<DIRECT_MAX;i++) if (root->direct[i]) printf(" %u", root->direct[i]);
    printf("\n\n");

    // Gather / entries
    entry_t entries[BS/sizeof(dirent64_t)];
    size_t entry_count = 0;
    for (int di=0; di<DIRECT_MAX; di++){
        uint32_t blk = root->direct[di];
        if (!blk) continue;
        const uint8_t* b = img + (size_t)blk * BS;
        size_t n = BS / sizeof(dirent64_t);
        for (size_t j=0;j<n;j++){
            const dirent64_t* d = (const dirent64_t*)(b + j*sizeof(dirent64_t));
            if (d->inode_no == 0) continue;
            entry_t e;
            e.ino = d->inode_no; e.type = d->type;
            memcpy(e.name, d->name, 58); e.name[58] = '\0';
            entries[entry_count++] = e;
        }
    }

    // Print directory table
    printf("== / directory entries ==\n");
    printf("%-6s  %-4s  %-s\n", "INODE", "TYPE", "NAME");
    for (size_t i=0;i<entry_count;i++){
        printf("%-6u  %-4s  %s\n", entries[i].ino,
               entries[i].type==2?"dir":(entries[i].type==1?"file":"?"),
               entries[i].name);
    }
    printf("\n");

    // Files under / : details
    printf("== Files under / (size, proj_id, direct blocks) ==\n");
    for (size_t i=0;i<entry_count;i++){
        if (entries[i].type != 1) continue; // only files
        uint32_t ino = entries[i].ino;
        if (ino==0 || ino > sb->inode_count) continue;
        const inode_t* fi = (const inode_t*)(itab + (size_t)(ino-1)*INODE_SIZE);

        printf("%s (inode %u): size=%" PRIu64 " bytes  proj_id=%u\n",
               entries[i].name, ino, fi->size_bytes, fi->proj_id);
        printf("  blocks:");
        for (int k=0;k<DIRECT_MAX;k++){
            if (fi->direct[k]){
                uint32_t ablk = fi->direct[k];
                uint64_t byte_off = (uint64_t)ablk * BS;
                printf(" %u(0x%08" PRIX64 ")", ablk, byte_off);
            }
        }
        printf("\n");
    }

    free(img);
    return 0;
}
