#include <stdio.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>

int main(void) {
    int counter = 1; // We start with the original parent
    pid_t root_pid = getpid();

    pid_t a, b, c;

    // For First fork
    if (getpid() == root_pid) {
        a = fork();
        if (a == 0) _exit(0);           // Then child exits in that case
        if (a > 0) {
            counter++;
            if (a % 2 != 0) {           //For  odd PID → create extra_fork 
                pid_t extra_fork = fork();
                if (extra_fork == 0) _exit(0);
                if (extra_fork > 0) counter++;
            }
        }
    }

    // For Second fork
    if (getpid() == root_pid) {
        b = fork();
        if (b == 0) _exit(0);
        if (b > 0) {
            counter++;
            if (b % 2 != 0) {
                pid_t extra_fork = fork();
                if (extra_fork == 0) _exit(0);
                if (extra_fork > 0) counter++;
            }
        }
    }

    // For Third fork
    if (getpid() == root_pid) {
        c = fork();
        if (c == 0) _exit(0);
        if (c > 0) {
            counter++;
            if (c % 2 != 0) {
                pid_t extra_fork = fork();
                if (extra_fork == 0) _exit(0);
                if (extra_fork > 0) counter++;
            }
        }
    }

    // Only root_pid prints
    if (getpid() == root_pid) {
        while (wait(NULL) > 0) {}
        printf("(Including first parent) Total created process: %d\n", counter);
    }

    return 0;
}
