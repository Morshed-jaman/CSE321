#include <stdio.h>
#include <stdlib.h>

int compare(const void *x, const void *y) {
    return (*(int *)y - *(int *)x); // For descending order
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Usecase: %s n1 n2 and so on ...\n", argv[0]);
        return 1;
    }

    int n = argc - 1;
    int arr[n];
    int i = 1, j = 0;
    while (i < argc) {
        arr[j++] = atoi(argv[i++]);
    }

    qsort(arr, n, sizeof(int), compare);

    printf("Array sorted in Descending order: ");
    for (int count = 0; count < n; count++) {
        printf("%d ", arr[count]);
    }
    printf("\n");

    return 0;
}
