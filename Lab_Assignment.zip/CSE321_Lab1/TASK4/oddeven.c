#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Usecase: %s n1 n2 and so on...\n", argv[0]);
        return 1;
    }

    int n = argc - 1;
    int array[n];

    
    for (int count = 1; count < argc; count++) {
        array[count - 1] = atoi(argv[count]);
    }

   
    for (int i = 0; i < n; i++) {
        if (array[i] % 2 != 0)
            printf("%d is Odd NUmber\n", array[i]);
            
        else
            printf("%d is Even Number\n", array[i]);
    }

    return 0;
}
