#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int compare(const void *x, const void *y) {
    return (*(int *)y - *(int *)x); // For descending order
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Usecase: %s n1 n2 and so on...\n", argv[0]);
        return 1;
    }

    int n = argc - 1;
    int arr[n];
    for (int count = 1; count < argc; count++) {
        arr[count - 1] = atoi(argv[count]);
    }

    pid_t pid = fork();

    if (pid < 0) {
        perror("Fork execution failed");
        return 1;
    }

    if (pid == 0) {
        // Child will sort and print (Descending) value
        qsort(arr, n, sizeof(int), compare);
        printf("Child: Array sorted in descending order: ");
        for (int i = 0; i < n; i++) {
            printf("%d ", arr[i]);
        }
        printf("\n");
        exit(0); // Child execution completed
    } else {
        wait(NULL); // Parent waitigg for child to complete
        // Parent: print odd/even for each number
        printf("Parent: Check Odd/Even number:\n");
        for (int k = 0; k < n; k++) {
            printf("%d is %s\n", arr[k], (arr[k] % 2 == 0) ? "EvenNum" : "OddNum");
        }
    }

    return 0;
}
