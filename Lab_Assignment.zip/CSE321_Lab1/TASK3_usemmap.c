#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <sys/mman.h>

int main() {
    // Create a Shared memory 
    int *total_count = mmap(NULL, sizeof(int), PROT_READ | PROT_WRITE,
                      MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    *total_count = 1; // Count the original parent process

    pid_t main_parent = getpid();
    pid_t a = fork();
    if (a == 0) __sync_fetch_and_add(total_count, 1);

    pid_t b = fork();
    if (b == 0) __sync_fetch_and_add(total_count, 1);

    pid_t c = fork();
    if (c == 0) __sync_fetch_and_add(total_count, 1);

    if (getpid() % 2 != 0) {
        pid_t extra_process = fork();
        if (extra_process == 0) {
            __sync_fetch_and_add(total_count, 1);
            sleep(.5);
            return 0;
        } else {
            __sync_fetch_and_add(total_count, 1);
        }
    }
    if (getpid() == main_parent) {
        sleep(1);
        printf("So,Total Process Created: %d\n", *total_count);
    }
    while (wait(NULL) > 0);

    return 0;
}
