#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    pid_t child_pid = fork();

    if (child_pid < 0) {
        perror("fork execution failed");
        return 1;
    }

    if (child_pid == 0) {
        // In child process execute
        printf("Child process ID: %d\n", getpid());

        for (int count = 0; count < 3; count++) {
            pid_t grandchild_pid = fork();
            if (grandchild_pid < 0) {
                perror("fork execution failed");
                return 1;
            }
            if (grandchild_pid == 0) {
             
                printf("Grand Child process ID: %d\n", getpid());
                return 0;
            }
            
        }
        
        for (int i = 0; i < 3; i++) wait(NULL);
        return 0;
    } else {
        // In parent process
        printf("Parent process ID: %d\n", getpid());
        wait(NULL); // Parent waits for child to complete its execution
    }

    return 0;
}
