#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>     
#include <unistd.h>   
#include <string.h>
#include <stdbool.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usecase: %s <fname>\n", argv[0]);
        return 1;
    }

    // Open the file for writing (create if it doesn't exist)
    int func = O_WRONLY;      // use for write only
    func = func | O_CREAT;   // use create a file if doesn't exist
    func = func | O_TRUNC;   // truncate it if exists
    mode_t mode_OGO= 0644;  
    int file_d = open(argv[1],func, mode_OGO);
    if (file_d < 0) {
        perror("Unable to opening the file");
        return 1;
    }

    char buffer[512];

    while (true) {
        printf("Enter a string(if -1 then exit): ");
        fgets(buffer, sizeof(buffer), stdin);

        // Any newline character will be removend if present
        buffer[strcspn(buffer, "\n")] = 0;

        if (strcmp(buffer, "-1") == 0) {
            break;
        }

        // Before write anything add newline
        strcat(buffer, "\n");
        write(file_d, buffer, strlen(buffer));
    }

    close(file_d);
    printf("inputs written to this file successfully : %s\n", argv[1]);

    return 0;
}
