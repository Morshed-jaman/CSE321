#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>


struct shared {
    char sel[100];
    int  b;
};


int main() {
     //------> Shared memory
    int shmid = shmget((key_t)102, sizeof(struct shared), 0666 | IPC_CREAT);
    void *data = shmat(shmid, NULL, 0);
    struct shared *pointer = (struct shared*)data;
    struct shared s_memory;         // Its a local working copy


    int pipe_fd[2];
    pipe(pipe_fd);
    //-----> For INPUT(Parent)
    printf("Provide Your Input From Given Options:\n");
    printf("1. Type a to Add Money\n");
    printf("2. Type w to Withdraw Money\n");
    printf("3. Type c to Check Balance\n");


    scanf("%99s", s_memory.sel);
    s_memory.b = 1000;
    *pointer = s_memory;


    printf("Your selection: %s\n\n", s_memory.sel);
    pid_t pID = fork();


    if (pID == 0) {
        //------> CHILD Operation
        close(pipe_fd[0]); // Here,only child writes
        s_memory = *pointer;


        if (!strcmp(s_memory.sel, "a")) {
            int amount;
            printf("Enter amount to be added:\n");
            scanf("%d", &amount);
            if (amount > 0) {
                s_memory.b = s_memory.b + amount;
                printf("Balance added successfully\n");
                printf("Updated balance after addition:\n");
                printf("%d\n", s_memory.b);
            } else {
                printf("Adding failed, Invalid amount\n");
            }


        } else if (!strcmp(s_memory.sel, "w")) {
            int amount;
            printf("Enter amount to be withdrawn:\n");
            scanf("%d", &amount);
            if (amount > 0 && s_memory.b > amount) {
                s_memory.b = s_memory.b - amount;
                printf("Balance withdrawn successfully\n");
                printf("Updated balance after withdrawal:\n");
                printf("%d\n", s_memory.b);
            } else {


                printf("Withdrawal failed, Invalid amount\n");


            }


        } else if (!strcmp(s_memory.sel, "c")) {
            printf("Your current balance is:\n");
            printf("%d\n", s_memory.b);
        } else {


            printf("Invalid selection\n");


        }


        //Use pipe to wrile last line of Parent
        const char msg[] =  "Thank you for using\n";
        write(pipe_fd[1], msg, sizeof(msg)-1);
        close(pipe_fd[1]);
        *pointer = s_memory;
        shmdt(data);
        _exit(0); //It terminates the current process immediately.
    }




    // ------> Main (Parent)
    close(pipe_fd[1]); // Here, Only parent reads
    wait(NULL); // wait for child to finish its execution




    char buf[256];
    int f = read(pipe_fd[0],buf,sizeof(buf)-1);
    if (f > 0) {
       buf[f] = '\0';
       printf("%s%s", buf, "_Memory");
    }
    close(pipe_fd[0]);




    //Clean Shared Memory
    shmdt(data);


    shmctl(shmid, IPC_RMID, NULL);
    return 0;
}
