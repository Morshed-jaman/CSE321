#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/wait.h>


struct msg {
    long type;
    char txt[6];
};


//Types of messages
#define TASK_LOGIN_TO_OTP      1   // Send OTP to workspace From login screen
#define TASK_OTP_TO_LOGIN      2   // OTP to login Verify
#define TASK_OTP_TO_MAIL       3   // OTP to email sending
#define TASK_MAIL_TO_LOGIN     4   // Verify email OTP for the login




int main(void) {


    //create Message Queue by ftok


    key_t keys = ftok(".", 'C');
    int qID = msgget(keys, 0666 | IPC_CREAT);


    //Login It asks for workspace name
    char workspace[64];
    printf("Please enter the workspace name:\n");
    if (scanf("%63s", workspace) != 1)
        return 0;
       


    if (strcmp(workspace, "cse321") != 0) {
        return (msgctl(qID, IPC_RMID, NULL),printf("Invalid workspace name\n"), 0);
    }


    //For sending workspace name to the OTP generator with Type: TASK_LOGIN_TO_OTP
    struct msg M;
    M.type = TASK_LOGIN_TO_OTP;
    memset(M.txt, 0, sizeof(M.txt));
    strncpy(M.txt, workspace, sizeof(M.txt));
    msgsnd(qID, &M, sizeof(M.txt), 0);


    printf("\nWorkspace name sent to otp generator from log in: %.*s\n\n", 6, M.txt);


    pid_t pID = fork();
    if (pID == 0) {
        //------------->OTP Generator (child)<-------------------
    //It reads workspace from Queue (Type : TASK_LOGIN_TO_OTP )
        struct msg rcv;


        msgrcv(qID, &rcv, sizeof(rcv.txt), TASK_LOGIN_TO_OTP , 0);
        printf("OTP generator received workspace name from log in: %.*s\n\n", 6, rcv.txt);


        //create OTP --->  Process id
        struct msg msgOTP;
        msgOTP.type = TASK_OTP_TO_LOGIN ;
        int pid = (int)getpid();
        snprintf(msgOTP.txt, sizeof(msgOTP.txt), "%d", pid);


        //Send OTP to login (Type: TASK_OTP_TO_LOGIN)
        msgsnd(qID, &msgOTP, sizeof(msgOTP.txt), 0);
        printf("OTP sent to log in from OTP generator: %s\n", msgOTP.txt);


        // It sends same OTP to mail (Type: TASK_OTP_TO_MAIL)
        msgOTP.type = TASK_OTP_TO_MAIL;
        msgsnd(qID, &msgOTP, sizeof(msgOTP.txt), 0);
        printf("OTP sent to mail from OTP generator: %s\n", msgOTP.txt);


        /* Fork for MAIL process */


        pid_t mailpID = fork();
        if (mailpID == 0) {
            //------------->MAIL (grandchild)<----------------


            struct msg mail_IN, mail_OUT;
            //Get OTP from Queue (Type: TASK_OTP_TO_MAIL)
            msgrcv(qID, &mail_IN, sizeof(mail_IN.txt), TASK_OTP_TO_MAIL, 0);
            printf("Mail received OTP from OTP generator: %s\n", mail_IN.txt);


            //Send same OTP to log in (Type: TASK_MAIL_TO_LOGIN)


            mail_OUT.type = TASK_MAIL_TO_LOGIN ;
            strncpy(mail_OUT.txt, mail_IN.txt, sizeof(mail_OUT.txt));
            msgsnd(qID, &mail_OUT, sizeof(mail_OUT.txt), 0);


            printf("OTP sent to log in from mail: %s\n", mail_OUT.txt);


            _exit(0);
        }


        //OTP generator waits for mail to finish
        wait(NULL);
        _exit(0);
    }


    //===================>> LOG IN (Parent) Continues <<===================


    //wait for otp And its child mail
    wait(NULL);


    //Read otp -----> log in


    struct msg from_OTP, from_Mail;
    msgrcv(qID, &from_OTP,  sizeof(from_OTP.txt),  TASK_OTP_TO_LOGIN , 0);
    printf("Log in received OTP from OTP generator: %s\n", from_OTP.txt);


    //read mail -----> log in
    msgrcv(qID, &from_Mail, sizeof(from_Mail.txt), TASK_MAIL_TO_LOGIN , 0);


    printf("Log in received OTP from mail: %s\n", from_Mail.txt);


    //Check
    int verify = strncmp(from_OTP.txt, from_Mail.txt, sizeof(from_OTP.txt));
    if (verify == 0) {
       printf("OTP Verified\n");
    } else {
       printf("OTP Incorrect\n");
    }
    //CleanUp


    msgctl(qID, IPC_RMID, NULL);
    return 0;
}
