// sleeping_st.c
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <stdint.h>




#define Total_students 10
#define Max_chairs 3


pthread_mutex_t mutex_lobby = PTHREAD_MUTEX_INITIALIZER;
sem_t sem_students;                                    //This semaphore use for ST sleeps
sem_t finish_sem[Total_students];                        // Student complete their consultation


int waiting_lobby[Max_chairs];
int q_front = 0, q_back = 0, wait_counter = 0;
int service_counter = 0;             // When a student actually leaves only then  this counter increase
int all_stdTh = 0;        // When all student threads have finished only then set




static void push_queue_method(int std_id){
    waiting_lobby[q_back] = std_id;
    q_back = (q_back + 1) % Max_chairs;
    wait_counter++;
}


static int pop_queue_method(void){
    int std_id = waiting_lobby[q_front];
    q_front = (q_front + 1) % Max_chairs;
    wait_counter--;
    return std_id;
}






// Student Thread ----->
static void* student_Thread_fn(void* args){
   int std_id = (int)(intptr_t)args;




   // determine student arrive in this order --> 0 ..... 9
   usleep((unsigned int)(std_id * 50 * 1000)); // 50ms * std_id --> Controlling the arrival time in Ascending order




   pthread_mutex_lock(&mutex_lobby);
   if (wait_counter < Max_chairs) {
       // Student will sit in a waiting chair
       push_queue_method(std_id);
       printf("Student %d started waiting for consultation\n", std_id); fflush(stdout);
       pthread_mutex_unlock(&mutex_lobby);




       //  count and wake up for ST
       sem_post(&sem_students);




       // Its used for wait others std until this specific student finishes consultation
       sem_wait(&finish_sem[std_id]);




       // After student left
       printf("Student %d finished getting consultation and left\n", std_id); fflush(stdout);
       pthread_mutex_lock(&mutex_lobby);
       service_counter++;
       printf("Number of served students: %d\n", service_counter); fflush(stdout);
       pthread_mutex_unlock(&mutex_lobby);
   } else {
       // All chair taken lobby is full now
       printf("No chairs remaining in lobby. Student %d Leaving.....\n", std_id); fflush(stdout);
       service_counter++;
       printf("Student %d finished getting consultation and left\n", std_id); fflush(stdout);
       printf("Number of served students: %d\n", service_counter); fflush(stdout);
       pthread_mutex_unlock(&mutex_lobby);
       return NULL;
   }
   return NULL;
}




//ST (thread) ----------------->
static void* std_tutor_fn(void* args){
   (void)args;
   while(1) {
       // It will sleep until at least one waiting student
       sem_wait(&sem_students);




       pthread_mutex_lock(&mutex_lobby);




       // exit if nobody is wait_counter AND everyone has already left
       if (wait_counter == 0 && all_stdTh && service_counter >= Total_students) {
           pthread_mutex_unlock(&mutex_lobby);
           break;
       }




       if (wait_counter > 0) {
           int std_id = pop_queue_method();
           int present_waiting = wait_counter;




           // Follow the sample output pattern
           printf("A waiting student started getting consultation\n"); fflush(stdout);
           printf("Number of students now waiting: %d\n", present_waiting); fflush(stdout);
           printf("ST giving consultation\n"); fflush(stdout);
           printf("Student %d is getting consultation\n", std_id); fflush(stdout);




           pthread_mutex_unlock(&mutex_lobby);




           
           usleep(120 * 1000); // 120ms fixed consulation duration for odering consistently




           //"finish & leave" When  exactly this student release
           sem_post(&finish_sem[std_id]);
       } else {
           pthread_mutex_unlock(&mutex_lobby);
       }
   }
   return NULL;
}


int main(void){
   sem_init(&sem_students, 0, 0);
   for (int n = 0; n < Total_students; ++n)
    sem_init(&finish_sem[n], 0, 0);


   pthread_t student_tutor, student[Total_students];
   pthread_create(&student_tutor, NULL, std_tutor_fn, NULL);


   // Generate thread std up to Total_students
   for (int i = 0; i < Total_students; ++i)
       pthread_create(&student[i], NULL, student_Thread_fn, (void*)(intptr_t)i);




   for (int j = 0; j < Total_students; ++j)
       pthread_join(student[j], NULL);


   // no further arrivals will occur, wake ST to check the exit
   pthread_mutex_lock(&mutex_lobby);
   all_stdTh = 1;
   pthread_mutex_unlock(&mutex_lobby);
   sem_post(&sem_students);




   pthread_join(student_tutor, NULL);
   return 0;
}













