#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>




const int MIN = 0;
const int MAX = 40;


int *fibonacci_arr;   // Create a Shared array for all the fib_numbers
int n;            // Generate Fibonacci up to term number n
int *indices;     // indices mention the Array of search indices
int s;            // s is number of searches


// Thread_1 ----> Generate sequences of Fibonacci
void *create_fibonacci_seq(void *args) {
   fibonacci_arr = malloc((n + 1) * sizeof(int));
   if (fibonacci_arr == NULL) {
       perror("malloc");
       pthread_exit(NULL);
   }
   if (n >= 0) {
    fibonacci_arr[0] = 0;
    }


   if (n >= 1) {
    fibonacci_arr[1] = 1;
   }


   for (int j = 2; j <= n; j++) {
       fibonacci_arr[j] = fibonacci_arr[j - 1] + fibonacci_arr[j - 2];
   }
   pthread_exit(NULL);
}



// Thread 2 ----> Fibonacci values search
void *fibonacci_search(void *args) {
   for (int i = 0; i < s; i++) {
       int temp = indices[i];
       if (temp < 0 || temp > n) {
           printf("result of search #%d = -1\n", i + 1);
       } else {
           printf("result of search #%d = %d\n", i + 1, fibonacci_arr[temp]);
           
       }
   }
   pthread_exit(NULL);
}




int main() {
   printf("Enter the term of fibonacci sequence:\n");
   if (scanf("%d", &n) != 1 || n > MAX || n < MIN) {
       printf("Input is Invalid. n has to be between %d and %d.\n", MIN, MAX);
       return 1;
   }




   printf("How many numbers you are willing to search?:\n");
   if (scanf("%d", &s) != 1 || s <= 0) {
       printf("Invalid searches number.\n");
       return 1;
   }




   indices = malloc(s * sizeof(int));
   if (!indices) {
       perror("malloc");
       return 1;
   }


   for (int count = 0; count < s; count++) {
       printf("Enter search %d:\n", count + 1);
       if (scanf("%d", &indices[count]) != 1) {
           printf("Invalid index.\n");
           free(indices);
           return 1;
       }
   }




   pthread_t th1, th2;


   // Thread 1 -----> It Generate Fibonacci
   pthread_create(&th1, NULL, create_fibonacci_seq, NULL);
   pthread_join(th1, NULL);


   // Fibonacci sequences print
   int idx = 0;
   while (idx <= n) {
        printf("a[%d] = %d\n", idx, fibonacci_arr[idx]);
        idx++;
   }


   // Thread 2 ------> Searching
   pthread_create(&th2, NULL, fibonacci_search, NULL);
   pthread_join(th2, NULL);


// Free all
   free(fibonacci_arr);
   free(indices);
   return 0;
}





