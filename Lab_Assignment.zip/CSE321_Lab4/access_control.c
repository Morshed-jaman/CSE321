#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// ----> Expanded it to fullfill  "add at least two new users/resources" requirement
#define MAX_USERS 5
#define MAX_RESOURCES 5
#define MAX_NAME_LEN 20

typedef enum{
    READ = 1,    // 001
    WRITE = 2,   // 010
    EXECUTE = 4  // 100
} Permission;

// User and Resource Definitions
typedef struct{
    char name[MAX_NAME_LEN];
} User;

typedef struct{
    char name[MAX_NAME_LEN];
} Resource;

// ACL Entry
typedef struct{
    char userName[MAX_NAME_LEN];
    int permissions; // bitmask of Permission
} ACLEntry;

typedef struct{
    Resource resource;
    ACLEntry entries[MAX_USERS];
    int count;
} ACLControlledResource;

// Capability Entry
typedef struct{
    char resourceName[MAX_NAME_LEN];
    int permissions; // bitmask of Permission
} Capability;

typedef struct{
    User user;
    Capability capabilities[MAX_RESOURCES];
    int count;
} CapabilityUser;

// ----------> Optional Enhancements <<For Dynamic Setup>> <----------
int addACLEntry(ACLControlledResource *acr, const char *userName, int perm){
    if(acr->count >= MAX_USERS) return 0;
    strncpy(acr->entries[acr->count].userName, userName, MAX_NAME_LEN-1);
    acr->entries[acr->count].userName[MAX_NAME_LEN-1] = '\0';
    acr->entries[acr->count].permissions = perm;
    acr->count++;
    return 1;
}
//---->Safely copy a string into a fixed-size array without risking overflow
//---->while ensuring the result is always null-terminated.
int addCapability(CapabilityUser *cu, const char *resourceName, int perm){
    if(cu->count >= MAX_RESOURCES) 
    return 0;
    strncpy(cu->capabilities[cu->count].resourceName, resourceName, MAX_NAME_LEN-1);
    cu->capabilities[cu->count].resourceName[MAX_NAME_LEN-1] = '\0';
    cu->capabilities[cu->count].permissions = perm;
    cu->count++;
    return 1;
}
// ---------------------------DONE------------------------------------

// Utility Functions
void printPermissions(int perm){
    if(perm == 0){
        printf("NONE");
        return;
    }
    int First = 1;
    if(perm & READ){
        printf("READ");
        First = 0;
    }
    if(perm & WRITE){
        if(!First) printf("|");
        printf("WRITE");
        First = 0;
    }
    if(perm & EXECUTE){
        if(!First) printf("|");
        printf("EXECUTE");   //---> This ensure I don't ever print NONE after this
        First = 0;
    }
}


int hasPermission(int userPerm, int requiredPerm){
    return (userPerm & requiredPerm) == requiredPerm;
}

// ACL System
void checkACLAccess(ACLControlledResource *res, const char *userName, int perm){
    for(int idx = 0; idx < res->count; idx++){
        if(strcmp(res->entries[idx].userName, userName) == 0){
            int granted = hasPermission(res->entries[idx].permissions, perm);
            printf("ACL Check: User %s requests ", userName);
            printPermissions(perm);
            printf(" on %s: Access %s\n", res->resource.name, granted ? "GRANTED" : "DENIED");
            return;
        }
    }

    printf("ACL Check: User %s has NO entry for resource %s: Access DENIED\n", userName, res->resource.name);
}

// Capability System
void checkCapabilityAccess(CapabilityUser *user, const char *resourceName, int perm){
    for(int j = 0;  j < user->count;  j++){
        if(strcmp(user->capabilities[j].resourceName, resourceName) == 0){
            int granted = hasPermission(user->capabilities[j].permissions, perm);
            printf("Capability Check: User %s requests ", user->user.name);
            printPermissions(perm);
            printf(" on %s: Access %s\n", resourceName, granted ? "GRANTED" : "DENIED");
            return;
        }
    }
    printf("Capability Check: User %s has NO capability for %s: Access DENIED\n", user->user.name, resourceName);
}

int main(){
    // Sample users and resources ---> its expanded to 5
    User users[MAX_USERS] = {{"Alice"}, {"Bob"}, {"Charlie"}, {"Daina"}, {"Ada"}};
    Resource resources[MAX_RESOURCES] = {{"File1"}, {"File2"}, {"File3"}, {"File4"}, {"File5"}};

    // ----------> ACL Setup <----------
    ACLControlledResource aclRes[MAX_RESOURCES];
    for(int idx=0;idx<MAX_RESOURCES;idx++){
        aclRes[idx].resource = resources[idx];
        aclRes[idx].count = 0;
    }


    // For File1 ACL-----> Alice (READ|WRITE), Bob (READ), Daina (EXECUTE)
    addACLEntry(&aclRes[0], "Alice", READ | WRITE);
    addACLEntry(&aclRes[0], "Bob", READ);
    addACLEntry(&aclRes[0], "Daina", EXECUTE);

    // For File2 ACL-----> Charlie (READ|EXECUTE) and  Ada (WRITE)
    addACLEntry(&aclRes[1], "Charlie", READ | EXECUTE);
    addACLEntry(&aclRes[1], "Ada", WRITE);

    // For File3 ACL-----> Bob (WRITE|EXECUTE)
    addACLEntry(&aclRes[2], "Bob", WRITE | EXECUTE);

    // For File4 ACL-----> Daina (READ|WRITE|EXECUTE) and Alice (READ)
    addACLEntry(&aclRes[3], "Daina", READ | WRITE | EXECUTE);
    addACLEntry(&aclRes[3], "Alice", READ);

    // For File5 ACL-----> Ada (READ) and Charlie (WRITE)
    addACLEntry(&aclRes[4], "Ada", READ);
    addACLEntry(&aclRes[4], "Charlie", WRITE);

    // ----------> Capability (Setup) <----------
    CapabilityUser capUsers[MAX_USERS];
    for(int n=0;n<MAX_USERS;n++){
        capUsers[n].user = users[n];
        capUsers[n].count = 0;
    }

    // Alice:-----> File1 (READ|WRITE), File4 (READ)
    addCapability(&capUsers[0], "File1", READ | WRITE);
    addCapability(&capUsers[0], "File4", READ);

    // Bob:-----> File1 (READ), File3 (WRITE|EXECUTE)
    addCapability(&capUsers[1], "File1", READ);
    addCapability(&capUsers[1], "File3", WRITE | EXECUTE);

    // Charlie:-----> File2 (READ|EXECUTE), File5 (WRITE)
    addCapability(&capUsers[2], "File2", READ | EXECUTE);
    addCapability(&capUsers[2], "File5", WRITE);

    // Daina:-----> File1 (EXECUTE), File4 (READ|WRITE|EXECUTE)
    addCapability(&capUsers[3], "File1", EXECUTE);
    addCapability(&capUsers[3], "File4", READ | WRITE | EXECUTE);

    // Ada:-----> File2 (WRITE), File5 (READ)
    addCapability(&capUsers[4], "File2", WRITE);
    addCapability(&capUsers[4], "File5", READ);

    // ----------> Test ACL For (>= 6) diverse cases handle <----------
    checkACLAccess(&aclRes[0], "Alice", READ);          // ----->expects GRANTED
    checkACLAccess(&aclRes[0], "Bob", WRITE);           // ----->expects DENIED
    checkACLAccess(&aclRes[0], "Charlie", READ);        // ----->no entry : DENIED
    checkACLAccess(&aclRes[1], "Charlie", EXECUTE);     // expects-----> GRANTED
    checkACLAccess(&aclRes[3], "Daina", READ | WRITE);   // expects-----> GRANTED <<has all>>
    checkACLAccess(&aclRes[4], "Ada", WRITE);           // expects-----> DENIED <<only READ>>
    checkACLAccess(&aclRes[2], "Bob", EXECUTE);         // expects-----> GRANTED
    checkACLAccess(&aclRes[3], "Alice", WRITE);         // expects-----> DENIED (Alice has only READ on File4)

    // ----------> Test Capability For (>= 6) diverse cases handle <----------
    checkCapabilityAccess(&capUsers[0], "File1", WRITE);         // Alice on File1 WRITE -----> Should GRANTED
    checkCapabilityAccess(&capUsers[1], "File1", WRITE);         // Bob on File1 WRITE -----> Should DENIED
    checkCapabilityAccess(&capUsers[2], "File2", READ | EXECUTE);// Charlie on File2 R+X -----> Should GRANTED
    checkCapabilityAccess(&capUsers[3], "File4", EXECUTE);       // Daina on File4 X ------> Should GRANTED
    checkCapabilityAccess(&capUsers[4], "File5", READ);          // Ada on File5 READ -----> Should GRANTED
    checkCapabilityAccess(&capUsers[0], "File3", READ);          // Alice no cap for File3 -----> should DENIED
    checkCapabilityAccess(&capUsers[2], "File5", WRITE | READ);  // Charlie has WRITE only on File5 -----> Should DENIED
    checkCapabilityAccess(&capUsers[4], "File2", EXECUTE);       // Ada has WRITE only on File2 -----> Should DENIED

    return 0;
}
